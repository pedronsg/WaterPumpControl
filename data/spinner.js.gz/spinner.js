function spinnerOn() {
  document.getElementById("overlay").style.display = "flex";
}

function spinnerOff() {
  document.getElementById("overlay").style.display = "none";
}